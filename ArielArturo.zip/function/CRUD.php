<?php 

    function loginUsuario($pdo, $email, $pass) {
        session_start();

        $select = $pdo->prepare("SELECT * FROM users WHERE email='$email' and pass='$pass' ");
        $select->setFetchMode(PDO::FETCH_ASSOC);
        $select->execute();
        $data=$select->fetch();

        $_SESSION['name'] = $data['name'];
        $_SESSION['email'] = $data['email'];
        $_SESSION['pass'] = $data['pass'];
    }

    function inserirUsuario($pdo, $name, $email , $senha) {

        $sql = 	"INSERT INTO `users`( `id`, `name`, `email`, `pass`, `post`) ".
                " VALUES (null , ".$name.", ".$email.", ".$senha.", 1)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
    }

    function getPost($pdo) {

        $select = $pdo->prepare("SELECT * FROM posts ");
        $select->setFetchMode(PDO::FETCH_ASSOC);
        $select->execute();
        $data=$select->fetch();
        
        if($data != false) {
            foreach($data as $product) {
                $results[] = array('post' => $product['post']  );
            }

            return $results;
        } else {

            return $data;
        }

    }

    function updatePost($pdo, $id, $descricao) {

        $select = $pdo->prepare("UPDATE posts SET post='$descricao' where id='$id'");
        $select = $pdo->prepare($select);
        $select->execute();
    }

    function insertPost($pdo, $descricao) {

        $select = $pdo->prepare("insert into `posts` (`id`, `descricao`) VALUES (null, ".$descricao." ) ");
        $stmt = $pdo->prepare($select);
        $stmt ->execute();
    }

    function excluirPost($pdo) {

        $select = $pdo->prepare("delete * from posts");
        $stmt = $pdo->prepare($select);
        $stmt->execute();
    }

?>