<?php 
    require_once "function/CRUD.php";

    $pdoConnection = require_once "connection.php";

    if(isset($_POST['entrar']) ) {

        $_POST['entrar'] = "";
        loginUsuario($pdoConnection, $_POST['email'], $_POST['senha']);
    }
    
    if( isset($_POST['inserir']) ) {
        $_POST['inserir'] = "";
        inserirUsuario($pdoConnection, $_POST['name'], $_POST['email'] , $_POST['senha']);
    }
    
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />

    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Blog do Marquinho</title>

    <style>
        .center-cols>.col {
            float: none;
            /* disable the float */
            display: inline-block;
            /* make blocks inline-block */
            text-align: initial;
            /* restore text-align to default */
        }
    </style>
</head>

<body class="blue lighten-4">
    <nav>
        <div class="nav-wrapper blue darken-2">
            <a href="index.php" class="brand-logo left"></a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><a href="index.php" class="blue lighten-2">Início</a></li>
                <?php if(!isset($_SESSION['name'])): ?>
                    <li><a href="login.php">Login</a></li>
                <?php endif?>
                <?php if(isset($_SESSION['name'])): ?>
                    <?php if($_SESSION['name'] == "123"): ?>
                        <li><a href="admin.php">Administrador</a></li>
                    <?php endif?>
                <?php endif?>
            </ul>
        </div>
    </nav>

    <div class="container">

        <section class="">
           
                <form action="login.php" method="post">
                    <h1>Login</h1>
                    <div class="row">
                        <div class="col s12">
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">account_circle</i>
                                    <input type="text" id="autocomplete-input" name="email" class="autocomplete">
                                    <label for="autocomplete-input">Login</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col s12">
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">adjust</i>
                                    <input type="text" id="autocomplete-input" name="senha" class="autocomplete">
                                    <label for="autocomplete-input">Senha</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" name="entrar" class="btn green black-text" href="login.php" >Logar</button>
                </form>

                <form action="login.php" method="post">
                    <h1>Cadastro</h1>
                    <div class="row">
                        <div class="col s12">
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">account_circle</i>
                                    <input type="text" id="autocomplete-input" name="name" class="autocomplete">
                                    <label for="autocomplete-input">Nome</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col s12">
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">account_circle</i>
                                    <input type="text" id="autocomplete-input" name="email" class="autocomplete">
                                    <label for="autocomplete-input">Email</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col s12">
                            <div class="row">
                                <div class="input-field col s12">
                                    <i class="material-icons prefix">adjust</i>
                                    <input type="text" id="autocomplete-input" name="senha" class="autocomplete">
                                    <label for="autocomplete-input">Senha</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="inserir" class="btn yellow black-text" href="login.php" >Cadastrar</button>
                </form>

                <br><br><br>
        </section>


    </div>

    <footer class="blue page-footer">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text">Rodapé</h5>
                    <p class="grey-text text-lighten-4">Texto qualquer no rodapé</p>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                © 2019 Copyright
            </div>
        </div>
    </footer>

    <!-- JavaScript no final do body para otimizar o carregamento -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script>
    </script>
</body>

</html>