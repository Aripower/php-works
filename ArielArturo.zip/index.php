<!DOCTYPE html>
<html lang="en">
<?php 
    session_start();

    require_once "function/CRUD.php";
	
    $pdoConnection = require_once "connection.php";

    if(isset($_SESSION['name'])) {
        $Posts = getPost($pdoConnection);
    }

    
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />

    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Blog do Marquinho</title>

    <style>
        .center-cols>.col {
            float: none;
            /* disable the float */
            display: inline-block;
            /* make blocks inline-block */
            text-align: initial;
            /* restore text-align to default */
        }
    </style>
</head>

<body class="blue lighten-4">
    <nav>
        <div class="nav-wrapper blue darken-2">
            <a href="index.php" class="brand-logo left"></a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><a href="index.php" class="blue lighten-2">Início</a></li>
                <?php if(!isset($_SESSION['name'])): ?>
                    <li><a href="login.php">Login</a></li>
                <?php endif?>
                <?php if(isset($_SESSION['name'])): ?>
                    <?php if($_SESSION['name'] == "123"): ?>
                        <li><a href="admin.php">Administrador</a></li>
                    <?php endif?>
                <?php endif?>
            </ul>
        </div>
    </nav>
    <h1 class="center">Blog do Marquinho</h1>
    <h5 class="center">O melhor blog de tecnologia</h5>

    <div class="container">

        <section class="">
            <div class="row center">
                <div class="col s5">
                <?php if(isset($Posts)): ?>
                    <?php foreach($Posts as $post) : ?>
                        <div class="card">
                                <div class="card-image">
                                    <img src="https://cdn.pixabay.com/photo/2017/10/25/15/19/clouds-2888277_960_720.jpg">
                                    <span class="card-title black-text">Titulo</span>
                                </div>
                                <div class="card-content">
                                    <p>I am a very simple card. I am good at containing small bits of information.
                                        I am convenient because I require little markup to use effectively.</p>
                                </div>
                                <div class="card-action">
                                    <a href="#">This is a link</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach;?>
                <?php endif?>
                </div>
            </div>

        </section>


    </div>
    <footer class="blue page-footer">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text">Rodapé</h5>
                    <p class="grey-text text-lighten-4">Texto qualquer no rodapé</p>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                © 2019 Copyright
            </div>
        </div>
    </footer>

    <!-- JavaScript no final do body para otimizar o carregamento -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script>
    </script>
</body>

</html>