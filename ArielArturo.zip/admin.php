<?php 
    session_start();

    require_once "function/CRUD.php";
    $pdoConnection = require_once "connection.php";

    if(isset($_POST['inserir']) )  {
        $_POST['inserir'] = "";
        insertPost($pdoConnection, $_POST['descricao']);
    } else if (isset($_POST['editar']) ) {

        $_POST['editar'] = "";
        updatePost($pdoConnection, $_SESSION['id'], $_POST['descricao']);

    } else if (isset($_POST['excluir'] ) ) {

        $_POST['excluir'] = "";
        excluirPosts($pdoConnection);
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />

    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Blog do Marquinho</title>

    <style>
        .center-cols>.col {
            float: none;
            /* disable the float */
            display: inline-block;
            /* make blocks inline-block */
            text-align: initial;
            /* restore text-align to default */
        }
    </style>
</head>

<body class="blue lighten-4">

    <nav>
        <div class="nav-wrapper blue darken-2">
            <a href="index.php" class="brand-logo left"></a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><a href="index.php" class="blue lighten-2">Início</a></li>
                <?php if(!isset($_SESSION['name'])): ?>
                    <li><a href="login.php">Login</a></li>
                <?php endif?>
                <?php if(isset($_SESSION['name'])): ?>
                    <?php if($_SESSION['name'] == "123"): ?>
                        <li><a href="admin.php">Administrador</a></li>
                    <?php endif?>
                <?php endif?>
            </ul>
        </div>
    </nav>

    <h1 class="center">Blog do Marquinho</h1>
    <h5 class="center">O melhor blog de tecnologia</h5>

    <div class="container">
        <div class="carousel">
            <a class="carousel-item" href="#one!"><img src="https://lorempixel.com/250/250/nature/1"></a>
            <a class="carousel-item" href="#two!"><img src="https://lorempixel.com/250/250/nature/2"></a>
            <a class="carousel-item" href="#three!"><img src="https://lorempixel.com/250/250/nature/3"></a>
            <a class="carousel-item" href="#four!"><img src="https://lorempixel.com/250/250/nature/4"></a>
            <a class="carousel-item" href="#five!"><img src="https://lorempixel.com/250/250/nature/5"></a>
        </div>
        <section class="center">
            
                <div class="row">
                    <form class="col s12" method="post" action="admin.php">
                        <div class="row">
                            <div class="input-field col s12">
                                <i class="material-icons prefix">title</i>
                                <input id="input_text" name="titulo" type="text" data-length="1000">
                                <label for="input_text">Título</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <i class="material-icons prefix">subtitles</i>
                                <textarea id="textarea2" name="descricao" class="materialize-textarea" data-length="1000"></textarea>
                                <label for="textarea2">Descrição</label>
                            </div>
                        </div>

                        <input type="submit" value="inserir" name="inserir" href="admin.php" class="waves-effect waves-light btn-large green black-text">

                        <input type="submit" value="editar" name="editar" href="admin.php" class="waves-effect waves-light btn-large yellow black-text">

                        <input type="submit" value="excluir" name="excluir" href="admin.php"  class="waves-effect waves-light btn-large red black-text">

                    </form>
                </div>

            
        </section>
    </div>
    <br>
    <footer class="blue page-footer">
        <div class="container">
            <div class="row">
                <div class="col l6 s12">
                    <h5 class="white-text">Rodapé</h5>
                    <p class="grey-text text-lighten-4">Texto qualquer no rodapé</p>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <div class="container">
                © 2019 Copyright
            </div>
        </div>
    </footer>

    <!-- JavaScript no final do body para otimizar o carregamento -->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <script>
        $(document).ready(function () {
            $('input#input_text, textarea#textarea2').characterCounter();
        });

        $(document).ready(function () {
            $('.carousel').carousel();
        });
    </script>
</body>

</html>